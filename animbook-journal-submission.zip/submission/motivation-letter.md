---
output: pdf_document
fontsize: 12pt
---

\thispagestyle{empty}
\today

Editor   
The R Journal  
\bigskip

Dear Dr. Mark van der Loo,
\bigskip

Please consider our article titled "animbook: Visualizing changes in performance measures and demographic affiliations using animation" for publication in the R journal.

The manuscript introduces the new package called `animbook`. The paper describe backgroud to generate animation and detailed about the functions available in the package. Two applications are provided illustrate the use for studying corporate performance and voters preferences.

The methods were motivated by an especially innovative visualization publish in the New York Times newspaper. The animbook package make it possible to produces the animation like this along with variations with R. The primary area of use is when categorical data is provided over time.

We believe the readers of the R Journal will find this article interesting and helpful.
\bigskip
\bigskip

Regards,
    
    
    
    
Krisanat Anukarnsakulchularp  
Department of Econometrics and Business Statistics
Monash University 
Melbourne, Australia  
krisanat.anu@gmail.com

\bigskip
